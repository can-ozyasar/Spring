package com.canoz.ilkSpringProjesi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IlkSpringProjesiApplication {

	public static void main(String[] args) {
		SpringApplication.run(IlkSpringProjesiApplication.class, args);
	}

}
